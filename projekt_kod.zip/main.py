from cli import P2PShell


def main():
    P2PShell().cmdloop()


if __name__ == "__main__":
    main()
